import { type ReactNode } from "react";
export type ServiceKey = string;
export type AnyService = Record<string, any>;
export type ServiceRegistry = Map<ServiceKey, AnyService>;
export declare function useServiceRegistry(): ServiceRegistry;
export declare function useService<T extends AnyService>(key: ServiceKey): T;
interface RegistryProviderProps {
    /** Pre-populate with initial services (e.g. from extension loader). */
    initial?: Record<ServiceKey, AnyService>;
    children: ReactNode;
}
export declare function RegistryProvider({ initial, children }: RegistryProviderProps): import("react/jsx-runtime").JSX.Element;
export {};
